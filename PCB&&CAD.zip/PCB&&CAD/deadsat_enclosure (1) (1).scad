// ============================================================
// DeadSat Resurrection — Ground Station Enclosure
// Dual Raspberry Pi 4 housing (Pi #1 Compute + Pi #2 RF)
// Far Away 2026 — CAD hardware deliverable
//
// Usage:
//   openscad -o enclosure.stl deadsat_enclosure.scad
//   (or open in the OpenSCAD GUI: Design > Render, then
//    File > Export > Export as STL)
//
// All dimensions in millimetres. Every measurement below comes
// directly from the CY-1 guide v3 "Enclosure Dimensions" table —
// change a value here and the whole model updates.
// ============================================================

/* [Outer Shell] */
ext_length   = 200;   // X — overall length
ext_width    = 120;   // Y — overall width
ext_height   = 80;    // Z — overall height
wall         = 3;     // wall thickness, all sides

/* [Internal Bays] */
// Pi #1 (left) and Pi #2 (right) bays are each
// 94 x 114 x 74mm internal, per spec — derived below from
// the outer shell + wall thickness + divider, shown explicitly
// for clarity and as a sanity check against the spec table.
bay_internal_w   = 94;
bay_internal_d   = 114;
bay_internal_h   = 74;
divider_thick    = 3;   // dividing wall between the two bays

/* [Port Cutouts — Rear Panel] */
hdmi_w   = 18;  hdmi_h   = 8;    // per HDMI port
usb_w    = 14;  usb_h    = 6;    // per USB port
eth_w    = 17;  eth_h    = 14;   // per Ethernet port
power_d  = 10;                   // power cable hole, diameter

/* [Top Panel] */
sma_d    = 8;    // SMA antenna hole, diameter

/* [Right Side Panel] */
sdr_w    = 30;   // RTL-SDR dongle slot
sdr_h    = 12;

/* [Rendering] */
$fn = 48;   // circle smoothness for holes/text curves

// ------------------------------------------------------------
// Derived geometry
// ------------------------------------------------------------
// Centre of the enclosure along X — this is where the dividing
// wall sits, splitting the interior into the Pi #1 (left) and
// Pi #2 (right) bays. 97mm from the left face, per spec.
divider_x = 97;

// Interior cavity (the "hole box" in the Tinkercad steps):
// outer shell minus wall thickness on every side.
cavity_l = ext_length - 2*wall;   // 194
cavity_w = ext_width  - 2*wall;   // 114
cavity_h = ext_height - 2*wall;   // 74

// Sanity-check echo at render time — compare against the spec
// table (94 x 114 x 74 per bay). Cavity is split by the divider
// into two halves; each half's length should be ~94mm.
echo("Cavity (L x W x H):", cavity_l, cavity_w, cavity_h);
echo("Each bay length (cavity_l - divider)/2 =",
     (cavity_l - divider_thick) / 2,
     " -- spec expects 94");

// ============================================================
// Main shell: outer box minus inner cavity minus divider slot
// ============================================================
module shell() {
    difference() {
        // Outer solid block
        cube([ext_length, ext_width, ext_height]);

        // Hollow out the interior, leaving `wall` thickness on
        // every side and an open top (no lid in this design —
        // matches "align hole box to top opening" in the guide).
        translate([wall, wall, wall])
            cube([cavity_l, cavity_w, cavity_h + wall]); // +wall
            // so the cut reaches through the top face cleanly
    }
}

// ============================================================
// Dividing wall between Pi #1 (left) and Pi #2 (right) bays
// ============================================================
module divider() {
    translate([divider_x, wall, wall])
        cube([divider_thick, cavity_w, cavity_h]);
}

// ============================================================
// Rear panel cutouts (Y = ext_width face, i.e. back of unit)
// Two HDMI + two USB + one Ethernet + one power hole per Pi,
// arranged left-to-right within each bay.
// ============================================================
module rear_cutouts() {

    // --- Pi #1 bay (left half: x from wall to divider_x) ---
    pi1_x0 = wall + 4;

    // HDMI x2, stacked
    translate([pi1_x0,            ext_width - wall - 0.1, 50])
        cube([hdmi_w, wall + 0.2, hdmi_h]);
    translate([pi1_x0,            ext_width - wall - 0.1, 38])
        cube([hdmi_w, wall + 0.2, hdmi_h]);

    // USB x2
    translate([pi1_x0 + hdmi_w + 4, ext_width - wall - 0.1, 50])
        cube([usb_w, wall + 0.2, usb_h]);
    translate([pi1_x0 + hdmi_w + 4, ext_width - wall - 0.1, 40])
        cube([usb_w, wall + 0.2, usb_h]);

    // Ethernet
    translate([pi1_x0 + hdmi_w + usb_w + 10, ext_width - wall - 0.1, 48])
        cube([eth_w, wall + 0.2, eth_h]);

    // Power cable hole (round) — placed low/right in bay 1
    translate([divider_x - 12, ext_width - wall - 0.1, 16])
        rotate([90, 0, 0])
            cylinder(h = wall + 0.2, d = power_d);

    // --- Pi #2 bay (right half: x from divider_x to ext_length) ---
    pi2_x0 = divider_x + divider_thick + 4;

    translate([pi2_x0,            ext_width - wall - 0.1, 50])
        cube([hdmi_w, wall + 0.2, hdmi_h]);
    translate([pi2_x0,            ext_width - wall - 0.1, 38])
        cube([hdmi_w, wall + 0.2, hdmi_h]);

    translate([pi2_x0 + hdmi_w + 4, ext_width - wall - 0.1, 50])
        cube([usb_w, wall + 0.2, usb_h]);
    translate([pi2_x0 + hdmi_w + 4, ext_width - wall - 0.1, 40])
        cube([usb_w, wall + 0.2, usb_h]);

    translate([pi2_x0 + hdmi_w + usb_w + 10, ext_width - wall - 0.1, 48])
        cube([eth_w, wall + 0.2, eth_h]);

    translate([ext_length - wall - 12, ext_width - wall - 0.1, 16])
        rotate([90, 0, 0])
            cylinder(h = wall + 0.2, d = power_d);
}

// ============================================================
// Top panel cutout — SMA antenna hole, centred over Pi #2 bay
// ============================================================
module top_cutout() {
    pi2_centre_x = divider_x + divider_thick
                 + (ext_length - (divider_x + divider_thick)) / 2;

    translate([pi2_centre_x, ext_width / 2, ext_height - wall - 0.1])
        cylinder(h = wall + 0.2, d = sma_d);
}

// ============================================================
// Right side panel cutout — RTL-SDR dongle slot
// (right side = high-X face, over Pi #2 bay)
// ============================================================
module side_cutout() {
    translate([ext_length - wall - 0.1, ext_width/2 - sdr_w/2, ext_height/2 - sdr_h/2])
        cube([wall + 0.2, sdr_w, sdr_h]);
}

// ============================================================
// Labels (engraved/embossed text on the relevant faces)
// Embossed slightly outward (+0.6mm) so they're visible without
// needing a multi-colour or two-step print.
// ============================================================
module label_front() {
    // Front panel = low-Y face. Place text just outside that
    // face, rotated to lie flat against it.
    translate([ext_length/2, 0.6, ext_height/2 + 6])
        rotate([90, 0, 0])
            linear_extrude(height = 0.6)
                text("DEADSAT GROUND STATION",
                     size = 9, halign = "center", valign = "center",
                     font = "Liberation Sans:style=Bold");

    // Version number, small, bottom-right of front panel
    translate([ext_length - 18, 0.6, 6])
        rotate([90, 0, 0])
            linear_extrude(height = 0.6)
                text("v1.0", size = 5,
                     halign = "center", valign = "center");
}

module label_sides() {
    // "Pi #1 COMPUTE" — left side panel (low-X face)
    translate([-0.6, ext_width/2, ext_height/2])
        rotate([90, 0, 90])
            linear_extrude(height = 0.6)
                text("Pi #1 COMPUTE", size = 7,
                     halign = "center", valign = "center",
                     font = "Liberation Sans:style=Bold");

    // "Pi #2 RF" — right side panel (high-X face)
    translate([ext_length + 0.6, ext_width/2, ext_height/2])
        rotate([90, 0, -90])
            linear_extrude(height = 0.6)
                text("Pi #2 RF", size = 7,
                     halign = "center", valign = "center",
                     font = "Liberation Sans:style=Bold");
}

module label_top() {
    // "ANTENNA" — top panel, above the SMA hole
    pi2_centre_x = divider_x + divider_thick
                 + (ext_length - (divider_x + divider_thick)) / 2;

    translate([pi2_centre_x, ext_width/2 - 14, ext_height - 0.6])
        linear_extrude(height = 0.6)
            text("ANTENNA", size = 6,
                 halign = "center", valign = "center",
                 font = "Liberation Sans:style=Bold");
}

// ============================================================
// Final assembly
// ============================================================
module enclosure() {
    difference() {
        union() {
            shell();
            divider();
        }
        rear_cutouts();
        top_cutout();
        side_cutout();
    }

    // Labels added on top (union, not subtracted) so they
    // remain as raised text rather than holes.
    color("white") {
        label_front();
        label_sides();
        label_top();
    }
}

enclosure();
